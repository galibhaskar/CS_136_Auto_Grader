import unittest
import subprocess
from gradescope_utils.autograder_utils.decorators import weight, tags
from utility import get_code_file_name
import ctypes
import os

code_file_name = get_code_file_name()


class TestReturn(unittest.TestCase):
    test_cases = [
        {"input": [1, 2, 3], "expected_output": 6, "weight": 2},
        {"input": [-1, -2, -3], "expected_output": -6, "weight": 2},
        {"input": [0, 0, 0, 0, 0, 0], "expected_output": 0, "weight": 2},
        {"input": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
            "expected_output": 55, "weight": 2},
        {"input": [-10, 5, 3, -2, 0, 8, -7],
            "expected_output": -3, "weight": 2},
        {"input": [], "expected_output": 0, "weight": 2}
    ]

    lib = None

    def compile_code(self):
        cmd = f"gcc -shared -o test.so {code_file_name}"
        result = subprocess.run(
            cmd, shell=True, capture_output=True, text=True)

        cmd = f"pwd"
        result = subprocess.run(
            cmd, shell=True, capture_output=True, text=True)
        print("compile code:", result)

        cmd = f"ls test.so"
        result = subprocess.run(
            cmd, shell=True, capture_output=True, text=True)
        print("compile code:", result)

    def test_all_return_test_cases(self):
        self.compile_code()

        self.lib = ctypes.CDLL(os.path.abspath("./test.so"))

        if self.lib:
            self.lib.calculateTotalInArray.argtypes = [
                ctypes.POINTER(ctypes.c_int), ctypes.c_int]

            self.lib.calculateTotalInArray.restype = ctypes.c_int

        for i, test_case in enumerate(self.test_cases):
            # locals()[f'test_{i+1}'] = weight(test_case['weight'])(lambda self,
            #                                                   index=i+1, info=test_case: self.return_value_test(index, info))
            self.return_value_test(i+1, test_case)

    @weight(2)
    def return_value_test(self, test_case_index, test_case_info):
        weight_value = test_case_info["weight"]

        input_arr = test_case_info["input"]

        expected_output = test_case_info["expected_output"]

        print("lib", self.lib)

        if self.lib:
            result = self.lib.calculateTotalInArray(
                (ctypes.c_int * len(input_arr))(*input_arr), len(input_arr))

            self.assertTrue(result == expected_output,
                        f"Test case {test_case_index} failed. Expected {expected_output}, but got {result}")

    # Add weight decorator to each test case
    # for i, test_case in enumerate(test_cases):
    #     locals()[f'test_{i+1}'] = weight(test_case['weight'])(lambda self,
    #                                                           index=i+1, info=test_case: self.return_value_test(index, info))