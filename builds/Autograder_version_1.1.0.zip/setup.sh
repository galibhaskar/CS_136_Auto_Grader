#!/usr/bin/env bash

apt-get install -y python3 python3-pip python3-dev gcc jq

pip3 install -r /autograder/source/requirements.txt
